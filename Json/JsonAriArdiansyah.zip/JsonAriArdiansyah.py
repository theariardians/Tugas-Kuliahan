# python obj dict to json
import json
a = {}
a['name'] = "Ari Ardiansyah"
a['from'] = "Indonesia"
a['skill'] = "Python","React"
 
print(json.dumps(a))